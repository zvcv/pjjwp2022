<?php

	$uid = $_POST["xuid"];
	$psw = $_POST["xpsw"];

	echo "User ID = " . $uid . "<br />";
	echo "Password = " . $psw;

?>