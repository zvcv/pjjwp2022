
		<div id="loginbox">
			<div id="logintitle">Login</div><br />
			<table border=0>
				<tr>
					<td>User ID:</td>
					<td><input type="text" id="xuid" name="xuid" /></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="password" id="xpsw" name="xpsw" /></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><input type="button" id="btnLogin" value="Login" onclick="bLogin()" /></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><a href="#">Forgot Password</a></td>
				</tr>
			</table>
		</div>