<!DOCTYPE html>
<html>
	<head>
		<title>Belajar Web App - Diklat I - 2022</title>
		<link id="icon" rel="shortcut icon" type="image/x-icon" href="images/icon.png" />
		
		<link rel="stylesheet" type="text/css" href="library/common.css" />
	</head>

	<body>
	
		<div id="loginbox">
			<div id="logintitle">Login</div><br />
			<table border=0>
				<tr>
					<td>User ID:</td>
					<td><input type="text" id="xuid" name="xuid" /></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="password" id="xpsw" name="xpsw" /></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><input type="submit" id="btnLogin" value="Login" /></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><a href="#">Forgot Password</a></td>
				</tr>
			</table>
		</div>
		
		
	</body>
</html>