<!DOCTYPE html>
<html>
	<head>
		<title>Belajar Web App - Diklat I - 2022</title>
		<link id="icon" rel="shortcut icon" type="image/x-icon" href="images/icon.png" />
	</head>

	<body>
	
		<!-- method bisa diganti dengan POST atau GET, script PHP harus disesuaikan -->
		<!-- action bisa diganti dengan terimadata.php atau menggunakan PHP_SELF -->
		<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
			<table border=0>
				<tr>
					<td>User ID:</td>
					<td><input name="xuid" type="text" /></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input name="xpsw" type="password" /></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><input value="Login" type="submit" /></td>
				</tr>
			</table>
		</form>	
		
		<!-- gunakan php script dibawah ini jika menggunakan PHP_SELF -->
		<?php
		
			if (isset($_POST["xuid"]) && isset($_POST["xpsw"])) {
				$uid = $_POST["xuid"];
				$psw = $_POST["xpsw"];

				echo "User ID = " . $uid . "<br />";
				echo "Password = " . $psw;		
			}
		
		?>
	
	</body>
</html>