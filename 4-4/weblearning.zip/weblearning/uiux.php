<!DOCTYPE html>
<html>
	<head>
		<title>Belajar Web App - Diklat I - 2022</title>
		<link id="icon" rel="shortcut icon" type="image/x-icon" href="images/icon.png" />
	</head>

	<body>
		<h2>Belajar UI dan UX - HTML only</h2><br />
		Ini adalah isi dari HTML <br /><br />
		
		<table border=1 width="100%">
			<tr>
				<td colspan="3">kolom A row 1</td>
				<td>kolom D row 1</td>
				<td rowspan="4">kolom E row 1</td>
			</tr>
			<tr>
				<td>kolom A row 2</td>
				<td>kolom B row 2</td>
				<td>kolom C row 2</td>
				<td>kolom D row 2</td>
			</tr>
			<tr>
				<td>kolom A row 3</td>
				<td colspan="2" rowspan="2">kolom B row 3</td>
				<td>kolom D row 3</td>
			</tr>
			<tr>
				<td>kolom A row 4</td>
				<td>kolom D row 4</td>
			</tr>
			<tr>
				<td>kolom A row 5</td>
				<td>kolom B row 5</td>
				<td>kolom C row 5</td>
				<td>kolom D row 5</td>
				<td>kolom E row 5</td>
			</tr>
		</table>
		<br /><br />
		
		<table border=0>
			<tr>
				<td>User ID:</td>
				<td><input name="uid" type="text" /></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input name="psw" type="password" /></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input name="userid" value="Login" type="submit" /></td>
			</tr>
		</table>
		<br /><br />
		
		<p>Ini adalah paragraph yang cukup panjang Ini adalah paragraph yang cukup panjang Ini adalah paragraph yang cukup panjang Ini adalah paragraph yang cukup panjang Ini adalah paragraph yang cukup panjang Ini adalah paragraph yang cukup panjang Ini adalah paragraph yang cukup panjang Ini adalah paragraph yang cukup panjang</p>
		
		<span>Ini menggunakan span</span>
		<br /><br />
		
		<img src="images/icon.png" height="100px" />
		<br /><br />
		
		<table>
			<tr>
				<td>
					<a href="http://www.google.com" target="_blank" >
						Ini link ke google.com
					</a>
				</td>
				<td>
					<a href="http://www.google.com">
						<img src="images/google.png" height="100px" />
					</a>			
				</td>
			</tr>
		</table>
		<br /><br />
		
		<div>Ini div</div>
		<br /><br />
		
		<ul>
			<li>list item 1</li>
			<li>list item 2</li>
			<li>list item 3</li>
			<li>list item 4</li>
			<li>list item 5</li>
		</ul>
		<br /><br />
		
		<ol>
			<li>list item 1</li>
			<li>list item 2</li>
			<li>list item 3</li>
			<li>list item 4</li>
			<li>list item 5</li>
		</ol>
		<br /><br />
		
		<form>
			ini adalah textbox: <input type="text" value="Ini textbox" /><br />
			ini adalah password: <input type="password" value="Ini Box Password" /><br />
			ini adalah button: <input type="button" value="Button" /><br />
			ini adalah submit: <input type="submit" value="Submit" /><br />
			ini adalah checkbox: <input type="checkbox" />Check disini<br />
			<textarea row="5">ini adalah text area</textarea><br />
			ini adalah combobox: 
			
			<select name="kategori" id="kategori">
				<option>Pilihan 1</option>
				<option>Pilihan 2</option>
				<option>Pilihan 3</option>
				<option>Pilihan 4</option>
				<option>Pilihan 5</option>
			</select>
			<br /><br />
			ini adalah radio button:
			<input type="radio" name="rdo" />Pilihan 1
			<input type="radio" name="rdo" />Pilihan 2
			<input type="radio" name="rdo" />Pilihan 3			
		</form>
		
		<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
		
		
	</body>
</html>