<?php

	include "library/dbconnect.php";

	$sql = "SELECT * FROM tablemovie";
	$result = runsqltext($sql);
	if ($result) {
	
		$numrow = mysqli_num_rows($result); //---cek jumlah data
		if ($numrow > 0) { //---data tersedia
		
			while ($row = mysqli_fetch_row($result)) {
				echo $row[0] . " " . $row[1] . " " . $row[2] . " " .  $row[3] . "<br />";
			}
			
			echo "Jumlah Data: " . $numrow . " record(s)";
			
		} else { //---data = 0
			echo "Data tidak tersedia";
		}
		
	}
	


?>