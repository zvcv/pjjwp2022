<?php
	$newline = "</br></br>";
	$a = "Hello back from PHP";

	echo $a;
	echo $newline;

	$b = 7;
	$c = 8;

	$d = $b + $c;

	echo $d;
	echo $newline;

	$e = 9;
	$f = "10";
	$g = $e + $f;

	echo $g;
	echo $newline;

	$operator = "-";

	if ($operator == "+") {
	    echo "Operasi Penjumlahan";
	} else {
	    if ($operator == "-") {
	       echo "Operasi Pengurangan";
  	    } else {
	       echo "Operasi Lainnya";
	    }
	}
	echo $newline;

	switch ($operator) {
	    case "+":
		echo "Operasi Penjumlahan";
		break;
	    case "-":
		echo "Operasi Pengurangan";
		break;
	    case "x":
		echo "Operasi Perkalian";
		break;
	    case "/":
		echo "Operasi Pembagian";
		break;
	    default:
		echo "Maaf, Operasi tidak dikenal";
		break;
	}
	echo $newline;


	for ($i = 1; $i < 10; $i++) {
	    echo $i . " ";
	}
	echo $newline;

	$i = 1;
	while ($i < 10) {
	    echo $i . " ";
	    $i = $i + 1;
	}
	echo $newline;

	$i = TRUE;
	$a = 1;
	while ($i) {
	    echo $a . " ";
	    $a = $a + 1;
	    if ($a > 15) {
		$i = FALSE;
	    }
	}
	echo $newline;

	//-----------loop dengan Do While
	$i = 0;
	Do {
	    echo $i . " "; //---pre processing	    
	    $i = $i + 1;
	    echo $i . " "; //---post processing
	}
        while ($i < 10);
	echo $newline;
	



?>